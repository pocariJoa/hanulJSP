package com.hanul.study;

public class WHDGKQDTO {
	
	private int answer ;
	private int ans;
	
	public WHDGKQDTO() {}
	
	public WHDGKQDTO(int answer, int ans) {
		super();
		this.answer = answer;
		this.ans = ans;
	}

	public int getAnswer() {
		return answer;
	}

	public void setAnswer(int answer) {
		this.answer = answer;
	}

	public int getAns() {
		return ans;
	}

	public void setAns(int ans) {
		this.ans = ans;
	}
	
	
	
	
	
	
}
